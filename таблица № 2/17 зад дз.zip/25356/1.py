f = open('17_25356.txt')
a = [int(x) for x in f]
c = 0

sp_end = []
m = max([x for x in a if str(x)[-2:] == '30'])

for i in range(len(a) - 2):
    k = [a[i], a[i + 1], a[i + 2]]
    k1 = [x for x in k if len(str(abs(x))) != 4]

    if len(k1) == len(k) and sum(k) > m:
        c += 1
        sp_end.append(sum(k))

print(c, max(sp_end))

# 1032 285423 +
