f = open('17_23404.txt')
a = [int(x) for x in f]

sp_end = []
c = 0

m = abs(min([x for x in a if str(x)[-3:] == '152' and len(str(abs(x))) >= 3]))

for i in range(len(a) - 1):
    k = [a[i], a[i + 1]]
    k1 = [abs(x) for x in k]

    if sum(k) < m:
        c += 1
        sp_end.append(sum(k1))

print(c, max(sp_end))
# 8631 199187 +
