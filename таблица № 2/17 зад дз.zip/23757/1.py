f = open('17_23757.txt')
a = [int(x) for x in f]
c = 0
sp_end = []
m = min([x for x in a if len(str(x)) == 2])

for i in range(len(a) - 1):
    k = [a[i], a[i + 1]]
    k1 = [x for x in k if len(str(x)) == 2]
    k2 = [x for x in k if ...]

    if len(k1) == 1 and sum(k) % m == 0:
        c += 1
        sp_end.append(sum(k))

print(c, max(sp_end))

# 150 9930 +
