f = open('17_21416.txt')
a = [int(x) for x in f]
sp = []
s = sum([x for x in a if abs(x) != x])

for i in range(len(a) - 2):
    k = [a[i], a[i + 1], a[i + 2]]

    if min(k) * max(k) > s:
        sp.append(sum(k))

print(len(sp), abs(max(sp)))

# 10007 7953 +
