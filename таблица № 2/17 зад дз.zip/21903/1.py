f = open('17_21903.txt')
a = [int(x) for x in f]
sp = []
m = min([x for x in a if str(x)[-2:] == '15' and len(str(abs(x))) == 3])

for i in range(len(a) - 2):
    k = [a[i], a[i + 1], a[i + 2]]
    k1 = [x for x in k if (-1) * x != x]

    if len(k1) == 3 and min(k) * max(k) > m ** 2:
        sp.append(min(k1) * max(k1))

print(len(sp), min(sp))

# 20 143360 -
# 3171 948880 -
# 3507 863808 +
