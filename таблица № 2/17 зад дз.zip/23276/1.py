f = open('17_23276.txt')
a = [int(x) for x in f]
sp = []
m = max([x for x in a if str(x)[-2:] == '25' and len(str(abs(x))) >= 2])

for i in range(len(a) - 2):
    k = [a[i], a[i + 1], a[i + 2]]
    k1 = [x for x in k if len(str(abs(x))) == 4]

    if len(k1) <= 2 and sum(k) <= m:
        sp.append(sum(k))

print(len(sp), max(sp))

# 6315 84523 +
