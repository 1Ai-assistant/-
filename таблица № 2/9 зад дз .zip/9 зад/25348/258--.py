f = open('25348.txt')
c = 0

for i in f:
    s = [int(x) for x in i.split()]
    s3 = [x for x in s if s.count(x) == 3]
    s_not3 = [x for x in s if s.count(x) == 1]
    if len(s3) == 3 and len(s_not3) == 4 and max(s) in s_not3:
            c += 1

print(c)
# 1595
