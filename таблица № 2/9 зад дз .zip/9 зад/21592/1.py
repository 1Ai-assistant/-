f = open('1.txt')
c = 0
sp_end = []

for i in f:
    s = [int(x) for x in i.split()]
    s1 = [x for x in s if s.count(x) == 1]  # Нужна 1 штука
    s2 = [x for x in s if s.count(x) == 2]  # 3 числа, каждое из которых повторяется 2 раза
    c += 1

    if len(s1) == 2 and len(s2) == 6 and (max(s2) - min(s2)) ** 2 > 2 * (s1[0] ** 2 + s1[1] ** 2):
        print(c)

# 29898 -
# 29938 + вторая попытка
