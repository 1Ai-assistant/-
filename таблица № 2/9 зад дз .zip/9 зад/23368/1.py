import pandas as pd

df = pd.read_excel('9_23368.xlsx', engine='openpyxl', header=None)
df.to_csv('9_23368.txt', sep='\t', index=False, header=False)

f = open('9_23368.txt')
c = 0
d = []

for i in f:
    c += 1
    sp = [int(x) for x in i.split()]
    sp1 = [x for x in sp if sp.count(x) == 1]
    sp_not_m = sorted(sp1)[1:-1]

    if len(sp1) == 5 and 2 * (max(sp1) + min(sp1)) == 3 * sum(sp_not_m):
        d.append(c)

f.close()
print(max(d))
# 13412 со второй попытки и с пандой с неросетью только смог
