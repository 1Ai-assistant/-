from math import prod

f = open('1.txt')
c = 0

for i in f:
    sp = [int(x) for x in i.split()]
    sp_ = [i for i in sp if sp.count(i) == 1]
    if len(sp_) == 7 and prod(sorted(sp)[:2]) <= sum(sorted(sp)[2:]):
        c += 1

print(c)

# 1920