c = 0
d = 0
s = 0
for i in open('1.txt'):
    c += 1
    sp = [int(i) for i in i.split()]
    sr_ar_m = (sorted(sp)[0] + sorted(sp)[-1]) / 2
    sr_ar = sum(sorted(sp)[0:-1]) / (len(sp) - 2)
    if sp == sorted(sp, reverse=True) and sr_ar_m > sr_ar:
        d = c
        s = sum(sp)
        break

print(d, s)