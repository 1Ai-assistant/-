f = open('2.txt')
c = 0

for i in f:
    c += 1

    k = [int(x) for x in i.split()]
    k1 = [x for x in k if k.count(x) == 1]  # Ни одно число не повторяется
    k2 = [x for x in k1 if x % 2 == 0]  # Четные
    k3 = [x for x in k1 if x % 2 != 0]  # Нечетные
    s_q = 0

    for a in k3:
        s_q += a ** 3

    if len(k1) == len(k) and sum(k2) ** 2 > s_q:
        print(c, '      ', sum(k))

# 246 +
