def f(a, b, m):
    if a + b >= 100:
        return m % 2 == 0
    if m == 0:
        return 0
    sp = [
        f(a + 3, b, m - 1),
        f(a * 2, b, m - 1),
        f(a, b + 3, m - 1),
        f(a, b * 2, m - 1)
    ]

    return any(sp) if m % 2 != 0 else all(sp)


print(min([x for x in range(1, 83) if f(17, x, 2)]))
print(sorted([x for x in range(1, 83) if f(17, x, 3) and not f(17, x, 1)])[:2])
print(max([x for x in range(1, 83) if f(17, x, 4) and not f(17, x, 2)]))

# 41
# [30, 31] -
# 37

# 40
# [20, 29] +
# 36
