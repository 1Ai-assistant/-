def f(n, m):
    if n < 28:
        return m % 2 == 0
    if m == 0:
        return 0
    sp = [
        f(n - 3, m - 1),
        f(n - 6, m - 1),
        f(n // 3, m - 1)
    ]

    return any(sp) if m % 2 != 0 else all(sp)


print(min([x for x in range(28, 1001) if f(x, 2)]))
print()
print(sorted([x for x in range(28, 1001) if f(x, 3) and not f(x, 1)])[:2])
print()
print(min([x for x in range(28, 1001) if f(x, 4) and not f(x, 2)]))

# 84
# [87, 88] +
# 93
