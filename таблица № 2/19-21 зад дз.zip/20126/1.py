def f(n, m):
    if n > 332:
        return m % 2 == 0
    if m == 0:
        return 0

    sp = [
        f(n + 3, m - 1),
        f(n + 8, m - 1),
        f(n * 2, m - 1)
    ]

    return any(sp) if m % 2 != 0 else all(sp)


print(min([x for x in range(1, 1001) if f(x, 2)]))
s = [x for x in range(1, 1_001) if f(x, 3) and not f(x, 1)]
print(min(s), max(s))
print(max([x for x in range(1, 1001) if f(x, 4) and not f(x, 2)]))

# 164
# 82 163 +
# 160
