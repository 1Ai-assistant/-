def f(n, m):
    if n >= 125:
        return m % 2 == 0
    if m == 0:
        return 0

    sp = [
        f(n + 2, m - 1),
        f(n + 4, m - 1),
        f(n * 2, m - 1)
    ]
    return any(sp) if m % 2 != 0 else all(sp)


print()
print(min([i for i in range(1, 125) if f(i, 2)]))
print()
print(sorted([i for i in range(1, 125) if f(i, 3) and not (f(i, 1))])[:2])
print()
print(min([i for i in range(1, 125) if f(i, 4) and not (f(i, 2))]))

# 61
# 31 57
# 55
