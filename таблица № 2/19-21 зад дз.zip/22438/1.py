def f(n, m):
    if n < 24:
        return m % 2 == 0
    if m == 0:
        return 0

    sp = [
        f(n - 3, m - 1),
        f(n - 5, m - 1),
        f(n // 2 if n % 2 == 0 else (n // 2) + 1, m - 1)
    ]

    return any(sp) if m % 2 != 0 else all(sp)


print(max([x for x in range(24, 1001) if f(x, 2)]))
s = [x for x in range(24, 1001) if f(x, 3) and not f(x, 1)]
print(min(s), max(s))
print(max([x for x in range(24, 1001) if f(x, 4) and not f(x, 2)]))


# 49
# 50 98 +
# 101
