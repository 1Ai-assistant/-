def f(a, b, m):
    if a + b <= 69: # тут затупил и написал 85 (50 + 35)
        return m % 2 == 0
    if m == 0:
        return 0

    sp = [
        f(a - 5, b + 2, m - 1),
        f(a // 2, b, m - 1),
        f(a + 2, b - 5, m - 1),
        f(a, b // 2, m - 1)
    ]

    return any(sp) if m % 2 != 0 else all(sp)


print(max([x for x in range(1, 1_001) if f(35, x, 2)]))
s = [x for x in range(1, 1_001) if f(35, x, 3) and not f(35, x, 1)]
print(min(s), max(s))
print(min([x for x in range(1, 1_001) if f(35, x, 4) and not f(35, x, 2)]))

# 102
# 103 205 неверный ответ
# 104

# 70
# 71 141 +
# 72
